export type { User } from "./user";
export type { Role } from "./role";
export type { Setting } from "./setting";

// Tipe data konten Landing page (dipindahkan bareng halaman dashboardnya)
export type { Project } from "./project";
export type { Statistic } from "./statistic";
export type { FooterSetting, FooterSocial } from "./footer";
export type { Menu } from "./menu";
export type { Service } from "./service";
export type { Testimonial } from "./testimonial";
export type { Team } from "./team";