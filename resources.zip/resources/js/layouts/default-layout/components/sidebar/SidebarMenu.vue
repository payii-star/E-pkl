﻿<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import { useRoute } from "vue-router";
import MainMenuConfig from "@/layouts/default-layout/config/MainMenuConfig";
import { sidebarMenuIcons } from "@/layouts/default-layout/config/helper";
import { useI18n } from "vue-i18n";
import { useAuthStore } from "@/stores/auth";
import { storeToRefs } from "pinia";

const authStore = useAuthStore();
const { user } = storeToRefs(authStore);

const { t, te } = useI18n();
const route = useRoute();
const scrollElRef = ref<null | HTMLElement>(null);

onMounted(() => {
    if (scrollElRef.value) {
        scrollElRef.value.scrollTop = 0;
    }
});

const translate = (text: string) => {
    if (te(text)) {
        return t(text);
    } else {
        return text;
    }
};

const isAdminUser = () => {
    const roleName = user?.value?.role?.name;
    return roleName === "admin" || roleName === "hr-admin";
};

// MainMenuConfig sudah berisi SEMUA item (termasuk item khusus admin,
// masing-masing dengan field `permission`-nya sendiri). checkPermission()
// di bawah sudah otomatis meloloskan semua item untuk isAdminUser(),
// jadi tidak perlu ada config terpisah untuk admin.
const sidebarMenuConfig = computed(() => MainMenuConfig);

const hasActiveChildren = (match: string) => {
    return route.path.indexOf(match) !== -1;
};

/**
 * Cek apakah item boleh ditampilkan.
 * - Jika item TIDAK punya field `permission` eksplisit di config,
 *   maka item selalu ditampilkan (default: publik untuk semua user login).
 * - Jika item PUNYA field `permission` eksplisit (misal: "journal-approval"),
 *   maka baru dicek terhadap daftar permission milik user.
 */
const checkPermission = (item: any) => {
    // Item dengan hideForAdmin selalu disembunyikan dari hr-admin,
    // apapun kondisinya — dicek duluan sebelum bypass admin di bawah.
    if (item?.hideForAdmin && isAdminUser()) return false;
    if (isAdminUser()) return true;
    if (!item?.permission) return true;
    return !!user?.value?.permission?.includes(item.permission);
};

const hasAnyAccessiblePage = (pages: any[] | undefined): boolean => {
    if (!pages) return false;

    return pages.some((p) => {
        if (p.heading) return checkPermission(p);
        if (p.sectionTitle) {
            if (!p.sub) return checkPermission(p);
            return checkPermission(p) && hasAnyAccessiblePage(p.sub);
        }
        return false;
    });
};
</script>

<template>
    <!--begin::sidebar menu-->
    <div class="app-sidebar-menu overflow-hidden flex-column-fluid">
        <!--begin::Menu wrapper-->
        <div id="kt_app_sidebar_menu_wrapper" class="app-sidebar-wrapper hover-scroll-overlay-y my-5" data-kt-scroll="true"
            data-kt-scroll-activate="true" data-kt-scroll-height="auto"
            data-kt-scroll-dependencies="#kt_app_sidebar_logo, #kt_app_sidebar_footer"
            data-kt-scroll-wrappers="#kt_app_sidebar_menu" data-kt-scroll-offset="5px" data-kt-scroll-save-state="true">
            <!--begin::Menu-->
            <div id="kt_app_sidebar_menu" class="menu menu-column menu-rounded menu-sub-indention px-3"
                data-kt-menu="true">
                <template v-for="(item, i) in sidebarMenuConfig" :key="i">
                    <div v-if="item.heading && hasAnyAccessiblePage(item.pages)" class="menu-item pt-5">
                        <div class="menu-content">
                            <span class="menu-heading fw-bold text-uppercase fs-7">
                                {{ translate(item.heading) }}
                            </span>
                        </div>
                    </div>
                    <template v-for="(menuItem, j) in item.pages" :key="j">
                        <template v-if="menuItem.heading && checkPermission(menuItem)">
                            <div class="menu-item">
                                <router-link v-if="menuItem.route" class="menu-link" exact-active-class="active"
                                    :to="menuItem.route">
                                    <span v-if="menuItem.keenthemesIcon || menuItem.bootstrapIcon" class="menu-icon">
                                        <i v-if="sidebarMenuIcons === 'bootstrap'" :class="menuItem.bootstrapIcon"
                                            class="bi fs-3"></i>
                                        <KTIcon v-else-if="sidebarMenuIcons === 'keenthemes'"
                                            :icon-name="menuItem.keenthemesIcon" icon-class="fs-2" />
                                    </span>
                                    <span class="menu-title">{{
                                        translate(menuItem.heading)
                                    }}</span>
                                </router-link>
                            </div>
                        </template>
                        <div v-if="menuItem.sectionTitle && menuItem.route && checkPermission(menuItem)"
                            :class="{ show: hasActiveChildren(menuItem.route) }" class="menu-item menu-accordion"
                            data-kt-menu-sub="accordion" data-kt-menu-trigger="click">
                            <span class="menu-link">
                                <span v-if="menuItem.keenthemesIcon || menuItem.bootstrapIcon" class="menu-icon">
                                    <i v-if="sidebarMenuIcons === 'bootstrap'" :class="menuItem.bootstrapIcon"
                                        class="bi fs-3"></i>
                                    <KTIcon v-else-if="sidebarMenuIcons === 'keenthemes'"
                                        :icon-name="menuItem.keenthemesIcon" icon-class="fs-2" />
                                </span>
                                <span class="menu-title">{{
                                    translate(menuItem.sectionTitle)
                                }}</span>
                                <span class="menu-arrow"></span>
                            </span>
                            <div :class="{ show: hasActiveChildren(menuItem.route) }" class="menu-sub menu-sub-accordion">
                                <template v-for="(item2, k) in menuItem.sub" :key="k">
                                    <div v-if="item2.heading && checkPermission(item2)" class="menu-item">
                                        <router-link v-if="item2.route" class="menu-link" exact-active-class="active"
                                            :to="item2.route">
                                            <span class="menu-bullet">
                                                <span class="bullet bullet-dot"></span>
                                            </span>
                                            <span class="menu-title">{{
                                                translate(item2.heading)
                                            }}</span>
                                        </router-link>
                                    </div>
                                    <div v-if="item2.sectionTitle && item2.route && checkPermission(item2)"
                                        :class="{ show: hasActiveChildren(item2.route) }" class="menu-item menu-accordion"
                                        data-kt-menu-sub="accordion" data-kt-menu-trigger="click">
                                        <span class="menu-link">
                                            <span class="menu-bullet">
                                                <span class="bullet bullet-dot"></span>
                                            </span>
                                            <span class="menu-title">{{
                                                translate(item2.sectionTitle)
                                            }}</span>
                                            <span class="menu-arrow"></span>
                                        </span>
                                        <div :class="{ show: hasActiveChildren(item2.route) }"
                                            class="menu-sub menu-sub-accordion">
                                            <template v-for="(item3, k) in item2.sub" :key="k">
                                                <div v-if="item3.heading && checkPermission(item3)" class="menu-item">
                                                    <router-link v-if="item3.route" class="menu-link"
                                                        exact-active-class="active" :to="item3.route">
                                                        <span class="menu-bullet">
                                                            <span class="bullet bullet-dot"></span>
                                                        </span>
                                                        <span class="menu-title">{{
                                                            translate(item3.heading)
                                                        }}</span>
                                                    </router-link>
                                                </div>
                                            </template>
                                        </div>
                                    </div>
                                </template>
                            </div>
                        </div>
                    </template>
                </template>
            </div>
            <!--end::Menu-->
        </div>
        <!--end::Menu wrapper-->
    </div>
    <!--end::sidebar menu-->
</template>